from django.shortcuts import render, redirect
from agent.models import Tour, TourDate, TourGallery, BookingOrders
from .forms import BookingOrderForm
from django.conf import settings
from django.http import JsonResponse
from django.views import View
import datetime, stripe


stripe.api_key = settings.STRIPE_SECRET_KEY



def home(request):
    top_tours = Tour.objects.filter(is_top=True)[:3]
    #this will dislay duplicated listing .. distinct method is working only with PostegresSQL
    #top_tours_gallery = TourGallery.objects.filter(tour__in=top_tours) #__in is usefull when you want to filter a lot of recors
    new_tours = Tour.objects.all().order_by('created_at')[:3][::-1] # [:3] means get last 3 record [::-1] used to reverse these records (des)
    #highly_rated_tours = Tour.objects.all().order_by('feedbacks')[:3] # get top last 3 record that currently have the highest feedback
    context = {
        'top_tours':top_tours,
        'new_tours':new_tours,
        #'highly_rated_tours':highly_rated_tours,
    }
    return render(request,"ui/home.html",context)


def success(request):
    return render(request,"ui/success.html")

def canceled(request):
    return render(request,"ui/canceled.html")

def CreateCheckoutSessionView(request,slug):
    if request.is_ajax and request.method == "POST":
        tour = Tour.objects.get(slug=slug)
        DOMAIN_NAME = "{}://{}".format(request.scheme,request.get_host())
        try:
            TourDate_instance = TourDate.objects.get(id=request.POST.get('planning'))
            form = BookingOrders(
                planning=TourDate_instance,
                full_name = request.POST.get('full_name'),
                email = request.POST.get('email'),
                phone = request.POST.get('phone'),
            )
            form.save()
            
            checkout_session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[
                    {
                        'price_data': {
                            'currency': 'usd',
                            'unit_amount': tour.price * 100,
                            'product_data': {
                                'name': "Tour: {}".format(tour.title),
                                'images': ["{}://{}{}".format(request.scheme,request.get_host(),tour.thumbnail.url)], #get full url of that thumbnail
                            },
                        },
                        'quantity': 1,
                    },
                ],
                
                mode='payment',
                success_url=DOMAIN_NAME + '/success/',
                cancel_url=DOMAIN_NAME + '/cancel/',
            )
            return JsonResponse({
                'id': checkout_session.id
            })
        except:
            return JsonResponse({
                'error': 'Please check your information and try again'
            })

now = datetime.datetime.now()
def single_tour(request,slug):
    tours = Tour.objects.get(slug=slug)
    galleries = TourGallery.objects.filter(tour=tours)
    planning = TourDate.objects.filter(tour=tours)
    form = BookingOrderForm()
    if request.method == "POST":
        form = BookingOrderForm(request.POST or None)
        if form.is_valid():
            form.save()
        else:
            form = BookingOrderForm()
    context = {
        'tours':tours,
        'galleries':galleries,
        'form':form,
        'planning':planning,
        'STRIPE_PUBLIC_KEY': settings.STRIPE_PUBLIC_KEY,
    }
    return render(request,"ui/single_tour.html",context)

def tours(request):
    tours = Tour.objects.all()
    context = {
        'tours':tours,
    }
    return render(request,"ui/tours.html",context)

